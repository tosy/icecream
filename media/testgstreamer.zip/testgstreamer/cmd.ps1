meson setup  --prefix=E:/gstreamer/out/ --reconfigure builddir
meson compile -C .\builddir\
meson install -C .\builddir\
