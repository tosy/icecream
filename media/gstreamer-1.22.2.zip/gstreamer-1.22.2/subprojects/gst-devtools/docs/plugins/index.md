# GstValidate plugins

GstValidate offers a plugin system to extend the checks and add new functionnality