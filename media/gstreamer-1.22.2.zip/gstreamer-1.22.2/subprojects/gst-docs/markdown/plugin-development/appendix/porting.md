---
title: Porting 0.10 plug-ins to 1.0
...

# Porting 0.10 plug-ins to 1.0

You can find the list of changes in the [Porting
to 1.0](http://gitlab.freedesktop.org/gstreamer/gstreamer/raw/master/docs/random/porting-to-1.0.txt)
document.
