---
short-description: Download and install GStreamer
...

#  Installing GStreamer

## Choose your platform by clicking on the corresponding logo

[![](images/mac.png)](installing/on-mac-osx.md)
[![](images/windows.png)](installing/on-windows.md)
[![](images/android.png)](installing/for-android-development.md)
[![](images/ios.jpeg)](installing/for-ios-development.md)
[![](images/linux.png)](installing/on-linux.md)

