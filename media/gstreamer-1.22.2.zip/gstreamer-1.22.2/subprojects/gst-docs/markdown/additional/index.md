# Additional documentation

This section references miscellaneous documents, such as design considerations.
