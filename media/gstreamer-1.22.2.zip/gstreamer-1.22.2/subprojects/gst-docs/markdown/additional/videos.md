---
short-description: Collection of GStreamer-related multimedia content
...

# Videos

## GStreamer Conference Videos and Slides

* [GStreamer Conference 2019: Videos and Slides] [(PDF slides)][2019]
* [GStreamer Conference 2018: Videos and Slides] [(PDF slides)][2018]
* [GStreamer Conference 2017: Videos and Slides] [(PDF slides)][2017]
* [GStreamer Conference 2016: Videos and Slides] [(PDF slides)][2016]
* [GStreamer Conference 2015: Videos and Slides] [(PDF slides)][2015]
* [GStreamer Conference 2014: Videos and Slides] [(PDF slides)][2014]
* [GStreamer Conference 2013: Videos and Slides] [(PDF slides)][2013]
* [GStreamer Conference 2012: Videos and Slides] [(PDF slides)][2012]
* [GStreamer Conference 2011: Videos and Slides] [(PDF slides)][2011]
* [GStreamer Conference 2010: Videos and Slides] [(PDF slides)][2010]

[GStreamer Conference 2019: Videos and Slides]: http://gstconf.ubicast.tv/channels/#gstreamer-conference-2019
[GStreamer Conference 2018: Videos and Slides]: http://gstconf.ubicast.tv/channels/#gstreamer-conference-2018
[GStreamer Conference 2017: Videos and Slides]: http://gstconf.ubicast.tv/channels/#gstreamer-conference-2017
[GStreamer Conference 2016: Videos and Slides]: http://gstconf.ubicast.tv/channels/#gstreamer-conference-2016
[GStreamer Conference 2015: Videos and Slides]: http://gstconf.ubicast.tv/channels/#gstreamer-conference-2015
[GStreamer Conference 2014: Videos and Slides]: http://gstconf.ubicast.tv/channels/#gstreamer-conference-2014
[GStreamer Conference 2013: Videos and Slides]: http://gstconf.ubicast.tv/channels/#gstreamer-conference-2013
[GStreamer Conference 2012: Videos and Slides]: http://gstconf.ubicast.tv/channels/#gstreamer-conference-2012
[GStreamer Conference 2011: Videos and Slides]: http://gstconf.ubicast.tv/channels/#conferences2011
[GStreamer Conference 2010: Videos and Slides]: http://gstconf.ubicast.tv/channels/#conferences2010
[2019]: https://gstreamer.freedesktop.org/data/events/gstreamer-conference/2019/
[2018]: https://gstreamer.freedesktop.org/data/events/gstreamer-conference/2018/
[2017]: https://gstreamer.freedesktop.org/data/events/gstreamer-conference/2017/
[2016]: https://gstreamer.freedesktop.org/data/events/gstreamer-conference/2016/
[2015]: https://gstreamer.freedesktop.org/data/events/gstreamer-conference/2015/
[2014]: https://gstreamer.freedesktop.org/data/events/gstreamer-conference/2014/
[2013]: https://gstreamer.freedesktop.org/data/events/gstreamer-conference/2013/
[2012]: https://gstreamer.freedesktop.org/data/events/gstreamer-conference/2012/
[2011]: https://gstreamer.freedesktop.org/data/events/gstreamer-conference/2011/
[2010]: https://gstreamer.freedesktop.org/data/events/gstreamer-conference/2010/
