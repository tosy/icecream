---
title: About GStreamer
...

# About GStreamer

This part gives you an overview of the technologies described in this
book.
