# Todo

For-later pages:
 - tutorials/qt-tutorials.md [tpm: this should all be rewritten from scratch with qmlglsink; QtGStreamer is outdated and unmaintained, we should not promote it]
   - basic-media-player.md
   - qt-gstreamer-vs-c-gstreamer.md
   - using-appsink-appsrc-in-qt.md

Miscellaneous:
 - faq/git.md should be renamed building.md and turned into general
   building Q+A or (better) point to a page we have for all that by then
 - faq/legal.md needs an overhaul, and be made more relevant
 - licensing.md and legal-information.md need to be reviewed + merged,
   possibly with FAQ section.

old sitemap:

        Installing the SDK
            Installing on Linux
            Installing on Mac OS X
            Installing on Windows
            Installing for Android development
            Installing for iOS development
            Building from source using Cerbero
        Tutorials
            Basic tutorials
            Playback tutorials
            Android tutorials
            iOS tutorials
            Table of Concepts
            Upcoming tutorials
        Deploying your application
            Mac OS X deployment
            Windows deployment
            Multiplatform deployment using Cerbero
        GStreamer reference
            gst-inspect
            gst-launch
        Legal information
        Frequently Asked Questions
        Contact
